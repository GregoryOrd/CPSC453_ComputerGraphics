// Copyright (c) 2020 Vladimir Solontsov
// SPDX-License-Identifier: MIT Licence

#include <fmt/core.h>

#include "gtest-extra.h"
